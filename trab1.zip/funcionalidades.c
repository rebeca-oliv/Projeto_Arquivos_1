/*
Karen Nanamy Kamo - NUSP: 15495932 
Rebeca de Oliveira Silva - NUSP: 11963923
*/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#include "structs.h"
#include "ler_arq.h"
#include "escrever_arq.h"
#include "funcionalidades.h"

// Função disponibilizada pelo monitor
// Função que conta e printa na tela do usuário quantidade de binário na tela
void BinarioNaTela(char *arquivo) {
    FILE *fs;
    if (arquivo == NULL || !(fs = fopen(arquivo, "rb"))) {
        fprintf(stderr,
                "ERRO AO ESCREVER O BINARIO NA TELA (função binarioNaTela): "
                "não foi possível abrir o arquivo que me passou para leitura. "
                "Ele existe e você tá passando o nome certo? Você lembrou de "
                "fechar ele com fclose depois de usar?\n");
        return;
    }

    fseek(fs, 0, SEEK_END);
    size_t fl = ftell(fs);

    fseek(fs, 0, SEEK_SET);
    unsigned char *mb = (unsigned char *)malloc(fl);
    fread(mb, 1, fl, fs);

    unsigned long cs = 0;
    for (unsigned long i = 0; i < fl; i++) {
        cs += (unsigned long)mb[i];
    }

    printf("%lf\n", (cs / (double)100));

    free(mb);
    fclose(fs);
}


/* ================================================================================

******************************FUNCIONALIDADE 1************************************

===================================================================================*/ 

/* Funcionalidades: 
   
   1. Abrir o arquivo csv
   2. Criar o arquivo de saída, que deve ser .bin
   3. Criar o Registro de Cabeçalho e armazenar o Reg. de Cabeçalho no arquivo.bin
   4. Ler cada Registro de Dados, armazenar na struct e alocar no arquivo.bin
   5. Chamar o BinarioNaTela

*/
void criar_arq_bin(){
  char nomeArq[100];
  char nomeArqBin[100];

  scanf("%s %s", nomeArq, nomeArqBin); // leitura dos inputs do usuário

  // abrir arquivo csv para leitura
  FILE *arqCsv = fopen(nomeArq, "r");
  if (arqCsv == NULL) {
    printf("Falha no processamento do arquivo.\n");
    return;
  }

  // abrir arquivo bin para escrita
  FILE *arqBin = fopen(nomeArqBin, "wb");
  if (arqBin == NULL) {
    printf("Falha no processamento do arquivo.\n");
    return;
  }

  RegistroCabecalho *h = NULL; // incialização do Registro de cabeçalho
  h = (RegistroCabecalho *) malloc(sizeof(RegistroCabecalho)); // alocação do registro de cabeçalho
  if (h == NULL){ // verifica se a alocação não ocorreu
    fclose(arqCsv);
    fclose(arqBin);
    return;
  }

  inicializar_cabecalho(h);
  escreve_reg_cab_bin(arqBin, h);

  // descarta a primeira linha com os nomes dos campos
  char bf_lixo[256];
  fgets(bf_lixo, sizeof(bf_lixo), arqCsv);

  // variáveis auxiliares para definir os valores finais do reg cab no final dos reg de dados
  // 1. ações relacionadas ao contEstacoes
  // 2. ações relacionadas ao contPares
  int contRRN = 0, contEstacoes = 0, contPares = 0;

  // 1. lista dos nomes das estações únicas
  char *estacoes[5000];

  // 2. lista de vetores com os pares codEstacao e codProxEstacao
  int paresUnicos[5000][2];

  //Enquanto o arquivo csv não acabar, leia linha por linha 
  while (check_eof(arqCsv)){
    RegistroDado r = ler_reg_dado_csv(arqCsv);

    // 1. precisa verificar se os nomes são iguais 
    int jaTemNome = 0;
    for (int i = 0; i < contEstacoes; i++){
      if (strcmp(r.nomeEstacao, estacoes[i]) == 0){
        jaTemNome = 1;
        break;
      }
    }

    if (!jaTemNome){
      // 1. faz uma cópia para não ser apagado depois com o free
      estacoes[contEstacoes] = strdup(r.nomeEstacao);
      contEstacoes++; // 1. soma toda vez que tem um nome único
    }

    // 2. precisa verificar se o par [codEstacao, codProxEstacao] já existe
    int jaTemPar = 0;
    if (r.codProxEstacao != -1){
      for (int i = 0; i < contPares; i++){
        // 2. verifica se já existe o par no vetor
        if (paresUnicos[i][0] == r.codEstacao && paresUnicos[i][1] == r.codProxEstacao){
          jaTemPar = 1;
          break;
        }
      }

      if (!jaTemPar){
        // 2. salvando o novo par
        paresUnicos[contPares][0] = r.codEstacao;
        paresUnicos[contPares][1] = r.codProxEstacao;
        contPares++;
      }
    }

    escreve_reg_dado_bin(arqBin, &r);

    // soma toda vez que tem um registro novo
    contRRN++;

    free_reg_dado(&r);
  }

  //Após ler todo o arquivo csv, atribui novas alterações para o Registro de Cabeçalho 
  h->status = '1';
  h->nroEstacoes = contEstacoes;
  h->proxRRN = contRRN; 
  h->nroParesEstacoes = contPares;
  
  escreve_reg_cab_bin(arqBin, h);

  // dando free na lista de nomes de estações únicas
  for (int i = 0; i < contEstacoes; i++)
    free(estacoes[i]);

  fclose(arqCsv);
  fclose(arqBin);

  free_reg_cab(h);

  BinarioNaTela(nomeArqBin);
}

//===============================================================================================================================//

void imprimir_reg_dado(RegistroDado *r){
  // esses dados nunca podem ser nulos, por isso, não serão tratados
  printf("%d ", r->codEstacao);
  printf("%s ", r->nomeEstacao);

  //Verifica se o campo do Reg. Dados for igual a -1, caso seja deve printar "NULO"
  //Caso não for nulo, possui um valor que deve ser printado em tela. 

  if (r->codLinha == -1) printf("NULO ");
  else printf("%d ", r->codLinha);

  if (strcmp(r->nomeLinha, "") == 0) printf("NULO ");
  else printf("%s ", r->nomeLinha);

  if (r->codProxEstacao == -1) printf("NULO ");
  else printf("%d ", r->codProxEstacao);

  if (r->distProxEstacao == -1) printf("NULO ");
  else printf("%d ", r->distProxEstacao);

  if (r->codLinhaIntegra == -1) printf("NULO ");
  else printf("%d ", r->codLinhaIntegra);

  if (r->codEstIntegra == -1) printf("NULO\n");
  else printf("%d\n", r->codEstIntegra);
}


/* ================================================================================

******************************FUNCIONALIDADE 2************************************

===================================================================================*/ 

/* Funcionalidades: 

  1. Abrir o arquivo.bin para leitura
  2. Ler o arquivo até o final, registro por registro (Linha por linha)
  3. Caso o registro exista, deve imprimir campo a campo

*/

void buscar_todos_reg_bin(){
  char nomeArqBin[100];
  scanf("%s", nomeArqBin); // leitura do input do usuário

  // abrir arquivo binário para leitura
  FILE *arqBin = fopen(nomeArqBin, "rb");
  if (arqBin == NULL) {
    printf("Falha no processamento do arquivo.\n");
    return;
  }

  RegistroCabecalho *h = ler_reg_cab_bin(arqBin);
  // dá erro caso o ponteiro seja NULL ou o arquivo esteja inconsistente
  if (h == NULL || h->status == '0') {
    printf("Registro inexistente.\n");
    fclose(arqBin);
    return;
  }

  //Enquanto não terminar o arquivo.bin, continue lendo os valores dos registros de dados
  while (check_eof(arqBin)){
    RegistroDado *r = ler_reg_dado_bin(arqBin);

    // verificando se o registro está logicamente removido
    if (r->removido == '0') imprimir_reg_dado(r);
    
    free_reg_dado(r);
    free(r);
  }

  free_reg_cab(h);
  fclose(arqBin);
}

//===============================================================================================================================//

void imprimir_reg_cab(RegistroCabecalho *h){
  //Não precisava para o trabalho 1
  //Usado para debugar o código pelas estudantes 
  printf("%c %d %d %d %d\n", h->status, h->topo, h->proxRRN, h->nroEstacoes, h->nroParesEstacoes);
}


// Função para buscar o Registro de Cabeçalho
//Não precisava para o trabalho 1
//Usado para debugar o código pelas estudantes 
void buscar_reg_cab_bin(){
  char nomeArqBin[100];
  scanf("%s", nomeArqBin);

  // abrir arquivo binário para leitura
  FILE *arqBin = fopen(nomeArqBin, "rb");
  if (arqBin == NULL) {
    printf("Falha no processamento do arquivo.\n");
    return;
  }

  // mover cursor para o início do arquivo
  fseek(arqBin, 0, SEEK_SET);

  RegistroCabecalho *h = ler_reg_cab_bin(arqBin);
  if (h == NULL) printf("Registro inexistente.\n");
  imprimir_reg_cab(h);

  free_reg_cab(h);
  fclose(arqBin);
}


// Função disponibilizada pelo monitor
void ScanQuoteString(char *str) {
    char R;

    while ((R = getchar()) != EOF && isspace(R))
        ; // ignorar espaços, \r, \n...

    if (R == 'N' || R == 'n') { // campo NULO
        getchar();
        getchar();
        getchar();       // ignorar o "ULO" de NULO.
        strcpy(str, ""); // copia string vazia
    } else if (R == '\"') {
        if (scanf("%[^\"]", str) != 1) { // ler até o fechamento das aspas
            strcpy(str, "");
        }
        getchar();         // ignorar aspas fechando
    } else if (R != EOF) { // vc tá tentando ler uma string que não tá entre
                           // aspas! Fazer leitura normal %s então, pois deve
                           // ser algum inteiro ou algo assim...
        str[0] = R;
        scanf("%s", &str[1]);
    } else { // EOF
        strcpy(str, "");
    }
}


// Função auxiliar para verificar se o valor é NULO
int verificar_nulo(char *valor){
  if (strcmp(valor, "NULO") == 0) return -1;
  return atoi(valor);
}


/* ================================================================================

******************************FUNCIONALIDADE 3************************************

===================================================================================*/ 

/* Funcionalidades: 

  1. Abrir o arquivo.bin para leitura
  2. Quantidade de buscas pelo usuário
  3. Quantidade de pares de busca pelo usuário 
  4. Entrada dos valores desejadas pelo usuário
  5. Compara os valores fornecido pelo usuário com os resgistros de dados
  6. Imprime, caso exista
*/
void buscar_reg_filtro(){
  char nomeArqBin[100];
  int quantBusca; 
  int quantPar; // armazena quantos pares o usuário quer
  
  // arrays para guardar os dados que devem ser filtrados
  char nomesCampos[100][100];
  char valoresCampos[100][100];

  scanf("%s %d", nomeArqBin, &quantBusca); // leitura dos inputs do usuário

  // abrir arquivo binário para leitura
  FILE *arqBin = fopen(nomeArqBin, "rb");
  if (arqBin == NULL) {
    printf("Falha no processamento do arquivo.\n");
    return;
  }

  RegistroCabecalho *h = ler_reg_cab_bin(arqBin);
  // dá erro caso o ponteiro seja NULL ou o arquivo esteja inconsistente
  if (h == NULL || h->status == '0') {
    printf("Registro inexistente.\n");
    fclose(arqBin);
    return;
  }

  // loop para buscar de acordo com a quantidade desejada
  for (int i = 0; i < quantBusca; i++){
    scanf("%d", &quantPar); // input de quantos pares vai desejar buscar

    // loop para a quantidade de pares desejadas
    for (int j = 0; j < quantPar; j++){
      scanf("%s", nomesCampos[j]); // lê o nome do campo desajado

      if (strcmp(nomesCampos[j], "nomeEstacao") == 0 ||
          strcmp(nomesCampos[j], "nomeLinha") == 0
      ){
        ScanQuoteString(valoresCampos[j]); // se for string, para ler "" 
      } else {
        scanf("%s", valoresCampos[j]);  // se for int, lê normalmente
      }

    }

    // mover para o byte 17 para buscar nos dados
    fseek(arqBin, 17, SEEK_SET);

    int naoEhInexistente = 0; // para ver se o registro foi printado ou não

    // fazer busca até o final do arquivo
    while (check_eof(arqBin)){
      RegistroDado *r = ler_reg_dado_bin(arqBin);

      // verificando se o registro está logicamente removido
      if (r != NULL && r->removido == '0'){
        int achou = 1; // para verificar se bate com todos os dados especificados, se não mudar, achou

        //Verificação se existe valor para cada campo.
        //Se achou = 1, corresponde que os valores buscados foram encontrados.
        // loop para a quantidade de pares que estão armazenados nas arrays
        for (int b = 0; b < quantPar; b++){

          
          if (strcmp(nomesCampos[b], "codEstacao") == 0){ // se o valor da array corresponde ao nome do campo
            if (verificar_nulo(valoresCampos[b]) != r->codEstacao) achou = 0; // se o valor da array  não corresponde ao valor armazenado na struct
          }

          // nomeEstacao nçao pode ser nulo
          else if (strcmp(nomesCampos[b], "nomeEstacao") == 0){ // se o valor da array corresponde ao nome do campo
            if (strcmp(valoresCampos[b], r->nomeEstacao) != 0) achou = 0; // se o valor da array  não corresponde ao valor armazenado na struct
          }

          else if (strcmp(nomesCampos[b], "codLinha") == 0){ // se o valor da array corresponde ao nome do campo
            if (verificar_nulo(valoresCampos[b]) != r->codLinha) achou = 0; // se o valor da array  não corresponde ao valor armazenado na struct
          }

          else if (strcmp(nomesCampos[b], "nomeLinha") == 0){ // se o valor da array corresponde ao nome do campo
            // se usuário buscou por NULO
            if (strcmp(valoresCampos[b], "") == 0){
              // se o registro tem nome, não serve pois é NULO a busca
              if (r->nomeLinha != NULL) achou = 0;
            }
            // se buscou por um nome real
            else {
              if (r->nomeLinha == NULL || strcmp(valoresCampos[b], r->nomeLinha) != 0) // se o valor da array  não corresponde ao valor armazenado na struct ou não possui valor
                achou = 0;
            }
          }

          else if (strcmp(nomesCampos[b], "codProxEstacao") == 0){ // se o valor da array corresponde ao nome do campo
            if (verificar_nulo(valoresCampos[b]) != r->codProxEstacao) achou = 0; // se o valor da array  não corresponde ao valor armazenado na struct
          }

          else if (strcmp(nomesCampos[b], "distProxEstacao") == 0){ // se o valor da array corresponde ao nome do campo
            if (verificar_nulo(valoresCampos[b]) != r->distProxEstacao) achou = 0; // se o valor da array  não corresponde ao valor armazenado na struct
          }

          else if (strcmp(nomesCampos[b], "codLinhaIntegra") == 0){ // se o valor da array corresponde ao nome do campo
            if (verificar_nulo(valoresCampos[b]) != r->codLinhaIntegra) achou = 0; // se o valor da array  não corresponde ao valor armazenado na struct
          }
            
          else if (strcmp(nomesCampos[b], "codEstIntegra") == 0){ // se o valor da array corresponde ao nome do campo
            if (verificar_nulo(valoresCampos[b]) != r->codEstIntegra) achou = 0; // se o valor da array  não corresponde ao valor armazenado na struct
          }

          // se já não atende a algum filtro, já para
          if (!achou) break;
        }

        if (achou){
          imprimir_reg_dado(r);
          naoEhInexistente = 1;
        }
      } 

      free_reg_dado(r);
      free(r);
    }

    if (!naoEhInexistente) printf("Registro inexistente.\n");

    // pular linha entre as buscas, menos no final
    if (i < quantBusca - 1) printf("\n");
  }
  
  free_reg_cab(h);
  fclose(arqBin);
}


/* ================================================================================

******************************FUNCIONALIDADE 4************************************

===================================================================================*/ 

/* Funcionalidades: 

  1.Abrir o arquivo.bin para leitura
  2. Calcula o byteoffset apartir do RRN de entrada
  3. Move o ponteiro para a posição desejada
  4. Tratamento de casos de registros removidos

*/
void buscar_reg_RRN(){
  char nomeArqBin[100];
  int rrn;

  // entrada dos dados desejados
  scanf("%s %d", nomeArqBin, &rrn);

  // abrir arquivo bin para leitura
  FILE *arqBin = fopen(nomeArqBin, "rb");
  if (arqBin == NULL) {
    printf("Falha no processamento do arquivo.\n");
    return;
  }

  RegistroCabecalho *h = ler_reg_cab_bin(arqBin);
  // dá erro caso o ponteiro seja NULL ou o arquivo esteja inconsistente
  // verificando se esse RRN existe nos registros
  if (h == NULL || rrn >= h->proxRRN || rrn < 0) {
    printf("Registro inexistente.\n");
    fclose(arqBin);
    return;
  }

  // calculando o byte que deve ser buscado
  int byteOffSet = 80 * rrn + 17;
  fseek(arqBin, byteOffSet, SEEK_SET);

  RegistroDado *r = ler_reg_dado_bin(arqBin);

  // verificando se o registro está logicamente removido
  if (r == NULL || r->removido == '1'){
    printf("Registro inexistente.\n");
  } else {
    imprimir_reg_dado(r);
  }

  free_reg_dado(r);
  free(r);
  free_reg_cab(h);

  fclose(arqBin);
}